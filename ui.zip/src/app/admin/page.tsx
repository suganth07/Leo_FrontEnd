"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import AnimatedBackground from "@/components/ui/AnimatedBackground";
import Navbar from "@/components/ui/navbar";
import LogoutButton from "./logout-button";
import { Toaster } from "sonner";
import { toast } from "sonner";
import { createClient } from "@supabase/supabase-js";
import { QRCodeCanvas } from "qrcode.react";
import axios from "axios";
import { 
  Camera, ArrowLeft, Settings, Users, User, FolderOpen, Image, Upload, 
  BarChart3, Bell, Lock, Trash2, Edit, Plus, RefreshCw, Calendar, 
  CheckCircle2, XCircle, Download, Search, MoreHorizontal, Eye, Database,
  QrCode, EyeOff, Shield, Grid3X3, X, Square, CheckSquare, Maximize2, ChevronLeft, ChevronRight,
  Cross
} from "lucide-react";


// Supabase configuration
const NEXT_PUBLIC_SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'fallback-key';
const NEXT_PUBLIC_SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://fallback.supabase.co';
const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL;

const supabase = createClient(NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY);

export default function AdminPage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<"dashboard" | "portfolios" | "uploads" | "settings">("dashboard");
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  
  // Enhanced state variables for new functionality
  const [folders, setFolders] = useState<{ id: string; name: string }[]>([]);
  const [selectedPortfolioId, setSelectedPortfolioId] = useState<string>("");
  const [allImages, setAllImages] = useState<{ id: string; name: string; url: string }[]>([]);
  const [displayImages, setDisplayImages] = useState<{ id: string; name: string; url: string }[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [selectedImages, setSelectedImages] = useState<Set<string>>(new Set());
  const [enlargedIndex, setEnlargedIndex] = useState<number | null>(null);
  const [isCreatingEncoding, setIsCreatingEncoding] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [pklExists, setPklExists] = useState(false);
  const [encodingStatus, setEncodingStatus] = useState<{exists: boolean, created_date?: string} | null>(null);
  const [matchLoading, setMatchLoading] = useState(false);
  const [folderPassword, setFolderPassword] = useState("");
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const [showPasswordInput, setShowPasswordInput] = useState(false);
  const [showQR, setShowQR] = useState(false);
  const [downloadLoading, setDownloadLoading] = useState(false);
  const qrRef = useRef<HTMLCanvasElement>(null);
  
  // Authentication check - redirect if not authenticated
  useEffect(() => {
    const authState = sessionStorage.getItem('isAuthenticated');
    if (!authState || authState !== 'true') {
      toast.error("Access denied. Please authenticate first.");
      router.push('/');
    } else {
      setIsAuthenticated(true);
      // Fetch folders from Google Drive
      fetchFolders();
    }
  }, [router]);

  // Fetch folders from Google Drive backend API
  const fetchFolders = async () => {
    try {
      const response = await axios.get(`${BASE_URL}/api/folders`);
      setFolders(response.data.folders || []);
    } catch (error) {
      console.error("Error fetching folders:", error);
      toast.error("Failed to load folders from Google Drive");
      // Fallback to mock data for UI purposes if API fails

    }
  };

  // Fetch images when portfolio is selected
  useEffect(() => {
    if (selectedPortfolioId) {
      fetchImages(selectedPortfolioId);
      checkEncodingStatus(selectedPortfolioId);
    } else {
      setEncodingStatus(null);
    }
  }, [selectedPortfolioId]);

  // Check if encoding exists for the selected folder
  const checkEncodingStatus = async (folderId: string) => {
    try {
      const response = await fetch(`${BASE_URL}/api/check_encoding_exists`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ folder_id: folderId }),
      });
      
      const data = await response.json();
      if (response.ok) {
        setEncodingStatus(data);
      } else {
        setEncodingStatus({ exists: false });
      }
    } catch (error) {
      console.error("Error checking encoding status:", error);
      setEncodingStatus({ exists: false });
    }
  };

  // Generate bypass URL for QR code
  const bypassUrl = typeof window !== "undefined" && selectedPortfolioId
    ? `${window.location.origin}/client?folderId=${selectedPortfolioId}&bypass=1`
    : "";

  // Filter images based on search term
  const filteredImages = displayImages.filter(image => 
    image.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  function getGoogleDriveViewUrl(fileId: string) {
    return `https://drive.google.com/uc?export=view&id=${fileId}`;
  }

  async function fetchImages(folderId: string) {
    try {
      const response = await axios.get(`${BASE_URL}/api/images?folder_id=${folderId}`);
      const transformedImages = response.data.images?.map((img: any) => ({
        ...img,
        url: getGoogleDriveViewUrl(img.id),
      })) || [];
      setAllImages(transformedImages);
      setDisplayImages(transformedImages);
    } catch (error) {
      console.error("Error fetching images:", error);
      toast.error("Failed to load images");
    }
  }

  const handleSetFolderPassword = async () => {
    if (!folderPassword) {
      toast.error("Please enter a password");
      return;
    }
    
    try {
      const selectedFolder = folders.find(folder => folder.id === selectedPortfolioId);
      
      const { error } = await supabase
        .from("folders")
        .upsert({
          folder_id: selectedPortfolioId,
          password: folderPassword,
          folder_name: selectedFolder?.name || "Unknown Folder",
        });
      
      if (error) {
        console.error("Supabase Error:", error);
        toast.error("Failed to set password");
      } else {
        toast.success("Password set successfully");
        setShowPasswordInput(false);
        setFolderPassword("");
      }
    } catch (err) {
      console.error("Error setting password:", err);
      toast.error("Something went wrong");
    }
  };

  const handleCreateEncoding = async () => {
    if (!selectedPortfolioId) {
      toast.error("Please select a portfolio first.");
      return;
    }
    
    setIsCreatingEncoding(true);
    try {
      const checkRes = await fetch(`${BASE_URL}/api/check_encoding_exists`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ folder_id: selectedPortfolioId }),
      });
      
      const checkData = await checkRes.json();
      if (!checkRes.ok) throw new Error(checkData.error || "Failed to check encoding");
      
      if (checkData.exists) {
        setPklExists(true);
        setShowConfirmation(true);
      } else {
        await createEncoding();
      }
    } catch (error) {
      console.error("Error creating encoding:", error);
      toast.error("Something went wrong");
    } finally {
      setIsCreatingEncoding(false);
    }
  };

  const createEncoding = async () => {
    setIsCreatingEncoding(true);
    try {
      const res = await fetch(`${BASE_URL}/api/images?folder_id=${selectedPortfolioId}`);
      const data = await res.json();
      const images = data.images?.map((img: any) => ({
        id: img.id,
        name: img.name,
        path_or_url: getGoogleDriveViewUrl(img.id),
      })) || [];

      const createRes = await fetch(`${BASE_URL}/api/create_encoding`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          folder_id: selectedPortfolioId,
          images: images,
        }),
      });

      const createData = await createRes.json();
      if (!createRes.ok) throw new Error(createData.error || "Encoding failed");
      
      toast.success(createData.status || "Encoding created successfully!");
      setPklExists(true);
      // Refresh encoding status after successful creation
      checkEncodingStatus(selectedPortfolioId);
    } catch (error) {
      console.error("Error creating encoding:", error);
      toast.error("Failed to create encoding");
    } finally {
      setIsCreatingEncoding(false);
      setShowConfirmation(false);
    }
  };

  const handleDeleteEncoding = () => {
    if (!selectedPortfolioId) {
      toast.error("Please select a portfolio first.");
      return;
    }
    setShowDeleteConfirmation(true);
  };

  const confirmDeleteEncoding = async () => {
    try {
      setDeleteLoading(true);
      setShowDeleteConfirmation(false);
      
      const res = await fetch(`${BASE_URL}/api/delete_encoding`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ folder_id: selectedPortfolioId }),
      });
      
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to delete encoding");
      
      toast.success(data.status || "Encoding deleted successfully!");
      setPklExists(false);
      setEncodingStatus({ exists: false });
    } catch (error) {
      console.error("Error deleting encoding:", error);
      toast.error("Failed to delete encoding");
    } finally {
      setDeleteLoading(false);
    }
  };

  const deleteEncodings = async () => {
    if (!selectedPortfolioId) {
      toast.error("Please select a portfolio first.");
      return;
    }
    
    try {
      setDeleteLoading(true);
      const res = await fetch(`${BASE_URL}/api/delete_encoding`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ folder_id: selectedPortfolioId }),
      });
      
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to delete encoding");
      
      toast.success(data.status || "Encoding deleted successfully!");
      setPklExists(false);
    } catch (error) {
      console.error("Error deleting encoding:", error);
      toast.error("Failed to delete encoding");
    } finally {
      setDeleteLoading(false);
    }
  };

  const handleConfirmYes = async () => {
    try {
      setShowConfirmation(false);
      setIsCreatingEncoding(true);
      await deleteEncodings();
      await createEncoding();
    } catch (error) {
      toast.error("Failed to replace encoding");
      setIsCreatingEncoding(false);
    }
  };

  const handleConfirmNo = () => {
    setShowConfirmation(false);
    setPklExists(false);
  };

  const handleDownloadQR = () => {
    const canvas = qrRef.current;
    if (canvas) {
      const url = canvas.toDataURL("image/jpeg");
      const a = document.createElement("a");
      a.href = url;
      a.download = "qr-code.jpg";
      a.click();
    }
  };

  const handleMatch = async () => {
    if (!file || !selectedPortfolioId) {
      toast.error("Please select a portfolio and upload an image!");
      return;
    }

    setMatchLoading(true);
    
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("folder_id", selectedPortfolioId);

      const response = await fetch(`${BASE_URL}/api/match`, {
        method: "POST",
        body: formData,
      });

      if (response.status === 404) {
        const errorData = await response.json();
        toast.error(errorData.detail || "Encoding file not found. Please create it first.");
        return;
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder("utf-8");
      let matchedImages: any[] = [];

      if (!reader) {
        toast.error("Connection failed.");
        return;
      }

      let fullText = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        fullText += decoder.decode(value, { stream: true });
        const events = fullText.split("\n\n");
        fullText = events.pop() || "";
        
        for (const event of events) {
          const jsonLine = event.replace(/^data:\s*/, "");
          if (jsonLine) {
            try {
              const data = JSON.parse(jsonLine);
              if (data.images) {
                const matchedImageIds = data.images.map((img: any) => img.id);
                const res = await fetch(`${BASE_URL}/api/images?folder_id=${selectedPortfolioId}`);
                const imageData = await res.json();
                matchedImages = imageData.images.filter((img: any) =>
                  matchedImageIds.includes(img.id)
                );
              }
            } catch (parseError) {
              console.error("Error parsing SSE data:", parseError);
            }
          }
        }
      }
      
      setDisplayImages(matchedImages);
      toast.success(`Found ${matchedImages.length} matching images!`);
    } catch (err) {
      console.error("Error matching faces:", err);
      toast.error("Failed to match faces.");
    } finally {
      setMatchLoading(false);
    }
  };

  const toggleSelectImage = (id: string) => {
    const newSelected = new Set(selectedImages);
    if (newSelected.has(id)) newSelected.delete(id);
    else newSelected.add(id);
    setSelectedImages(newSelected);
  };

  const handleDownloadSelected = async (imagesToDownload: Set<string> | null = null) => {
    const imagesToProcess = imagesToDownload || selectedImages;
    
    if (imagesToProcess.size === 0) return;
    
    try {
      setDownloadLoading(true);

      for (const fileId of imagesToProcess) {
        const metadataRes = await fetch(`${BASE_URL}/api/file-metadata?file_id=${fileId}`);
        if (!metadataRes.ok) throw new Error(`Failed to fetch metadata for ${fileId}`);
        const { name } = await metadataRes.json();

        const fileRes = await fetch(`${BASE_URL}/api/file-download?file_id=${fileId}`);
        if (!fileRes.ok) throw new Error(`Failed to download file ${fileId}`);
        const blob = await fileRes.blob();

        const url = window.URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", name || `${fileId}.jpg`);
        document.body.appendChild(link);
        link.click();
        link.remove();
      }
      
      toast.success("Download complete!");
    } catch (error) {
      console.error("Error downloading files:", error);
      toast.error("Download failed.");
    } finally {
      setDownloadLoading(false);
    }
  };

  // Show loading or redirect while checking authentication
  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Verifying access...</p>
        </div>
      </div>
    );
  }
  

  const handleRefresh = () => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      toast.success("Dashboard data refreshed");
      setIsLoading(false);
    }, 1200);
  };
  
  const handleCreatePortfolio = () => {
    toast.info("Create portfolio functionality will be implemented in the next phase");
  };

  const handleDeletePortfolio = (id: number) => {
    toast.success(`Portfolio ${id} would be deleted (mock)`);
  };

  const handleEditPortfolio = (id: number) => {
    toast.info(`Edit portfolio ${id} functionality will be implemented in the next phase`);
  };
  
  return (
    <div className="min-h-screen bg-background transition-colors duration-300 relative">
      <AnimatedBackground />
      <Toaster position="top-center" />
      
      {/* Navbar */}
      <Navbar />
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Admin Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-primary/10 rounded-lg">
                <Settings className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">Admin Dashboard</h1>
                <p className="text-muted-foreground">Manage your photography studio</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <LogoutButton />
              <Button 
                variant="outline"
                size="sm"
                onClick={handleRefresh}
                disabled={isLoading}
                className="flex items-center gap-1.5"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                    Refreshing...
                  </>
                ) : (
                  <>
                    <RefreshCw className="h-3.5 w-3.5" />
                    Refresh
                  </>
                )}
              </Button>
              <Button 
                variant="outline"
                size="sm"
                onClick={() => router.push("/client")}
                className="flex items-center gap-1.5"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
                Client Portal
              </Button>
            </div>
          </div>
          
          {/* Navigation Tabs */}
          <div className="flex flex-wrap items-center gap-2 border-b">
            <Button 
              variant={activeTab === "dashboard" ? "default" : "ghost"}
              size="sm"
              onClick={() => setActiveTab("dashboard")}
              className="rounded-none rounded-t-lg border-b-2 border-b-transparent data-[state=active]:border-b-primary"
              data-state={activeTab === "dashboard" ? "active" : "inactive"}
            >
              <BarChart3 className="mr-1.5 h-4 w-4" />
              Dashboard
            </Button>
            <Button 
              variant={activeTab === "uploads" ? "default" : "ghost"}
              size="sm"
              onClick={() => setActiveTab("uploads")}
              className="rounded-none rounded-t-lg border-b-2 border-b-transparent data-[state=active]:border-b-primary"
              data-state={activeTab === "uploads" ? "active" : "inactive"}
            >
              <Upload className="mr-1.5 h-4 w-4" />
              Uploads
            </Button>
            <Button 
              variant={activeTab === "settings" ? "default" : "ghost"}
              size="sm"
              onClick={() => setActiveTab("settings")}
              className="rounded-none rounded-t-lg border-b-2 border-b-transparent data-[state=active]:border-b-primary"
              data-state={activeTab === "settings" ? "active" : "inactive"}
            >
              <Settings className="mr-1.5 h-4 w-4" />
              Settings
            </Button>
          </div>
          
          {/* Portfolio Selection Section */}
          <Card className="border border-border/60 mb-6">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <FolderOpen className="h-5 w-5 text-primary" />
                Portfolio Selection
              </CardTitle>
              <CardDescription>
                Select a portfolio to enable advanced features and management
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="portfolio-select">Active Portfolio</Label>
                  <Select value={selectedPortfolioId} onValueChange={setSelectedPortfolioId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select portfolio for enhanced features..." />
                    </SelectTrigger>
                    <SelectContent>
                      {folders.map(folder => (
                        <SelectItem key={folder.id} value={folder.id}>
                          {folder.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                {selectedPortfolioId && (
                  <div className="flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Portfolio selected - Advanced features are now available in the tabs below</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Confirmation Dialog for Encoding */}
          {showConfirmation && (
            <Card className="border-destructive/50 bg-destructive/5 mb-6">
              <CardContent className="pt-6">
                <div className="text-center space-y-4">
                  <p className="text-lg font-medium">Existing encoding found. Replace it?</p>
                  <div className="flex gap-3 justify-center">
                    <Button
                      variant="destructive"
                      onClick={handleConfirmYes}
                      disabled={isCreatingEncoding}
                    >
                      {isCreatingEncoding ? "Replacing..." : "Yes, Replace"}
                    </Button>
                    <Button variant="outline" onClick={handleConfirmNo}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Delete Confirmation Dialog */}
          {showDeleteConfirmation && (
            <Card className="border-destructive/50 bg-destructive/5 mb-6">
              <CardContent className="pt-6">
                <div className="text-center space-y-4">
                  <div className="flex items-center justify-center mb-4">
                    <div className="p-3 bg-destructive/20 rounded-full">
                      <Trash2 className="h-6 w-6 text-destructive" />
                    </div>
                  </div>
                  <p className="text-lg font-medium">Delete Encoding?</p>
                  <p className="text-sm text-muted-foreground">
                    This will permanently remove the AI facial recognition data for this portfolio. This action cannot be undone.
                  </p>
                  <div className="flex gap-3 justify-center">
                    <Button
                      variant="destructive"
                      onClick={confirmDeleteEncoding}
                      disabled={deleteLoading}
                    >
                      {deleteLoading ? "Deleting..." : "Yes, Delete"}
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setShowDeleteConfirmation(false)}
                      disabled={deleteLoading}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          
          {/* Content Area */}
          <div className="py-4">
            {/* Dashboard Tab */}
            {activeTab === "dashboard" && (
              <>
                {!selectedPortfolioId ? (
                  <>
                    {/* Stats Cards */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                      <Card className="border border-border/60">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-lg flex items-center gap-2">
                            <FolderOpen className="h-5 w-5 text-blue-500" />
                            Portfolios
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          {/* <div className="text-3xl font-bold mb-1">{mockStats.totalPortfolios}</div> */}
                          <p className="text-muted-foreground text-sm">Active collections</p>
                        </CardContent>
                      </Card>
                      
                      <Card className="border border-border/60">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-lg flex items-center gap-2">
                            <Image className="h-5 w-5 text-purple-500" />
                            Images
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          {/* <div className="text-3xl font-bold mb-1">{mockStats.totalImages}</div> */}
                          <p className="text-muted-foreground text-sm">Total photos</p>
                        </CardContent>
                      </Card>
                      
                      <Card className="border border-border/60">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-lg flex items-center gap-2">
                            <Users className="h-5 w-5 text-green-500" />
                            Clients
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          {/* <div className="text-3xl font-bold mb-1">{mockStats.activeClients}</div> */}
                          <p className="text-muted-foreground text-sm">Active clients</p>
                        </CardContent>
                      </Card>
                      
                      <Card className="border border-border/60">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-lg flex items-center gap-2">
                            <Database className="h-5 w-5 text-amber-500" />
                            Storage
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          {/* <div className="text-3xl font-bold mb-1">{mockStats.totalStorage}</div> */}
                          <p className="text-muted-foreground text-sm">Used space</p>
                        </CardContent>
                      </Card>
                    </div>
                    
                    {/* Recent Activity and Quick Actions */}
                    {/* <div className="grid md:grid-cols-2 gap-6">
                      <Card className="border border-border/60">
                        <CardHeader>
                          <CardTitle className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Bell className="h-5 w-5 text-primary" />
                              Recent Activity
                            </div>
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="flex items-start gap-3 pb-3 border-b border-border/60">
                            <div className="p-1.5 bg-green-100 dark:bg-green-900/30 rounded-full">
                              <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
                            </div>
                            <div className="space-y-0.5 flex-1">
                              <p className="text-sm font-medium">New portfolio uploaded</p>
                              <p className="text-xs text-muted-foreground">Wedding collection for Smith family</p>
                              <p className="text-xs text-muted-foreground">Today, 10:23 AM</p>
                            </div>
                          </div>
                          <div className="flex items-start gap-3 pb-3 border-b border-border/60">
                            <div className="p-1.5 bg-blue-100 dark:bg-blue-900/30 rounded-full">
                              <User className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                            </div>
                            <div className="space-y-0.5 flex-1">
                              <p className="text-sm font-medium">New client registered</p>
                              <p className="text-xs text-muted-foreground">Johnson Photography Studios</p>
                              <p className="text-xs text-muted-foreground">Yesterday, 2:45 PM</p>
                            </div>
                          </div>
                          <div className="flex items-start gap-3 pb-3 border-b border-border/60">
                            <div className="p-1.5 bg-amber-100 dark:bg-amber-900/30 rounded-full">
                              <Bell className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                            </div>
                            <div className="space-y-0.5 flex-1">
                              <p className="text-sm font-medium">Portfolio password changed</p>
                              <p className="text-xs text-muted-foreground">Corporate Event 2023</p>
                              <p className="text-xs text-muted-foreground">2 days ago</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card className="border border-border/60">
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <Calendar className="h-5 w-5 text-primary" />
                            Upcoming Sessions
                          </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="flex items-center justify-between gap-4 pb-3 border-b border-border/60">
                            <div className="flex items-center gap-3">
                              <div className="p-2 bg-primary/10 rounded-md">
                                <Calendar className="h-4 w-4 text-primary" />
                              </div>
                              <div>
                                <p className="text-sm font-medium">Johnson Wedding</p>
                                <p className="text-xs text-muted-foreground">Tomorrow, 2:00 PM</p>
                              </div>
                            </div>
                            <Button variant="outline" size="sm">View</Button>
                          </div>
                          <div className="flex items-center justify-between gap-4 pb-3 border-b border-border/60">
                            <div className="flex items-center gap-3">
                              <div className="p-2 bg-primary/10 rounded-md">
                                <Camera className="h-4 w-4 text-primary" />
                              </div>
                              <div>
                                <p className="text-sm font-medium">Corporate Headshots</p>
                                <p className="text-xs text-muted-foreground">Mar 15, 10:00 AM</p>
                              </div>
                            </div>
                            <Button variant="outline" size="sm">View</Button>
                          </div>
                          <div className="flex items-center justify-between gap-4">
                            <div className="flex items-center gap-3">
                              <div className="p-2 bg-primary/10 rounded-md">
                                <Image className="h-4 w-4 text-primary" />
                              </div>
                              <div>
                                <p className="text-sm font-medium">Product Photography</p>
                                <p className="text-xs text-muted-foreground">Mar 18, 1:30 PM</p>
                              </div>
                            </div>
                            <Button variant="outline" size="sm">View</Button>
                          </div>
                        </CardContent>
                      </Card>
                    </div> */}
                  </>
                ) : (
                  /* Enhanced Dashboard with AI Encoding Management */
                  <div className="space-y-6">
                    <Card className="border border-border/60">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Database className="h-5 w-5 text-primary" />
                          AI Encoding Management
                        </CardTitle>
                        <CardDescription>
                          Create and manage AI facial recognition encodings for the selected portfolio
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        {/* Encoding Status Display */}
                        {encodingStatus?.exists && (
                          <div className="mb-4 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                            <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                              <CheckCircle2 className="w-4 h-4" />
                              <span className="text-sm font-medium">Encoding exists</span>
                            </div>
                            {encodingStatus.created_date && (
                              <p className="text-xs text-green-600 dark:text-green-500 mt-1">
                                Created: {new Date(encodingStatus.created_date).toLocaleString()}
                              </p>
                            )}
                          </div>
                        )}
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <Button
                            onClick={handleCreateEncoding}
                            disabled={isCreatingEncoding}
                            className="flex items-center gap-2 h-20 text-left justify-start"
                            variant="outline"
                          >
                            <div className="flex flex-col items-start">
                              <div className="flex items-center gap-2 mb-1">
                                {isCreatingEncoding ? (
                                  <div className="w-5 h-5 border-2 border-muted-foreground/30 border-t-foreground rounded-full animate-spin" />
                                ) : (
                                  <Database className="w-5 h-5" />
                                )}
                                <span className="font-medium">
                                  {isCreatingEncoding ? "Creating Encoding..." : "Create Encoding"}
                                </span>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                Generate AI facial recognition data
                              </span>
                            </div>
                          </Button>
                          
                          <Button
                            onClick={handleDeleteEncoding}
                            disabled={deleteLoading || !encodingStatus?.exists}
                            className="flex items-center gap-2 h-20 text-left justify-start text-destructive hover:text-destructive"
                            variant="outline"
                          >
                            <div className="flex flex-col items-start">
                              <div className="flex items-center gap-2 mb-1">
                                {deleteLoading ? (
                                  <div className="w-5 h-5 border-2 border-muted-foreground/30 border-t-destructive rounded-full animate-spin" />
                                ) : (
                                  <Trash2 className="w-5 h-5" />
                                )}
                                <span className="font-medium">
                                  {deleteLoading ? "Deleting Encoding..." : "Delete Encoding"}
                                </span>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                {encodingStatus?.exists ? "Remove AI recognition data" : "No encoding to delete"}
                              </span>
                            </div>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </>
            )}
            
            {/* Portfolios Tab */}
            {/*  */}
                      {/* {filteredPortfolios.length === 0 ? (
                        <div className="p-8 text-center text-muted-foreground">
                          No portfolios found matching "{searchQuery}"
                        </div>
                      ) : (
                        filteredPortfolios.map((portfolio) => (
                          <div key={portfolio.id} className="grid grid-cols-12 gap-3 p-3 hover:bg-muted/50 border-t">
                            <div className="col-span-5 flex items-center gap-2">
                              <FolderOpen className="h-4 w-4 text-primary" />
                              <span>{portfolio.name}</span>
                            </div>
                            <div className="col-span-3 flex items-center">
                              <span>{portfolio.client}</span>
                            </div>
                            <div className="col-span-2 flex items-center">
                              <span>{portfolio.images} photos</span>
                            </div>
                            <div className="col-span-2 flex items-center justify-end gap-1">
                              <Button 
                                variant="ghost" 
                                size="icon"
                                onClick={() => handleEditPortfolio(portfolio.id)} 
                                title="Edit"
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon"
                                onClick={() => handleDeletePortfolio(portfolio.id)} 
                                title="Delete"
                              >
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </div>
                        ))
                      )} */}
                    {/* </div>
                  </CardContent>
                </Card>
              </div>
            )} */}
            
            {/* Uploads Tab */}
            {activeTab === "uploads" && (
              <div className="space-y-6">
                {!selectedPortfolioId ? (
                  <Card className="border border-border/60">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Upload className="h-5 w-5 text-primary" />
                        Image Upload
                      </CardTitle>
                      <CardDescription>
                        Upload new images to client portfolios
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid gap-4">
                        <div className="grid gap-2">
                          <Label htmlFor="portfolio">Select Portfolio</Label>
                          <Select>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a portfolio" />
                            </SelectTrigger>
                            <SelectContent>
                              {/* {mockPortfolios.map(portfolio => (
                                <SelectItem key={portfolio.id} value={portfolio.id.toString()}>
                                  {portfolio.name} - {portfolio.client}
                                </SelectItem>
                              ))} */}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="file-upload">Upload Images</Label>
                          <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                            <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                            <p className="text-sm font-medium mb-1">Drag & drop images here</p>
                            <p className="text-xs text-muted-foreground mb-3">or</p>
                            <Button>Select Files</Button>
                            <p className="text-xs text-muted-foreground mt-3">Supported formats: JPG, PNG, HEIC (max 25MB each)</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button className="flex items-center gap-2" disabled>
                        <Upload className="h-4 w-4" />
                        Upload Images
                      </Button>
                    </CardFooter>
                  </Card>
                ) : (
                  /* Enhanced Upload with AI Matching */
                  <div className="space-y-6">
                    {/* Upload Preview */}
                    {file && (
                      <Card className="border border-border/60">
                        <CardHeader>
                          <CardTitle className="text-lg">Upload Preview</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="flex items-center gap-4">
                            <img
                              src={URL.createObjectURL(file)}
                              className="w-16 h-16 object-cover rounded-lg border border-border"
                              alt="Upload preview"
                            />
                            <div className="flex-1">
                              <p className="font-medium truncate">{file.name}</p>
                              <p className="text-sm text-muted-foreground">{Math.round(file.size/1024)}KB</p>
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setFile(null)}
                              className="text-destructive hover:text-destructive"
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* AI Processing Card */}
                    <Card className="border border-border/60">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Search className="h-5 w-5 text-primary" />
                          AI Face Matching
                        </CardTitle>
                        <CardDescription>
                          Upload a reference photo to find matching faces in the selected portfolio
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <Button
                            onClick={() => document.getElementById('file-input')?.click()}
                            className="flex items-center gap-2 h-20 text-left justify-start"
                            variant="outline"
                          >
                            <div className="flex flex-col items-start">
                              <div className="flex items-center gap-2 mb-1">
                                <Upload className="w-5 h-5" />
                                <span className="font-medium">Upload Reference</span>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                Select a master photo for matching
                              </span>
                            </div>
                          </Button>
                          
                          <Button
                            onClick={handleMatch}
                            disabled={matchLoading || !file}
                            className="flex items-center gap-2 h-20 text-left justify-start"
                            variant="outline"
                          >
                            <div className="flex flex-col items-start">
                              <div className="flex items-center gap-2 mb-1">
                                {matchLoading ? (
                                  <div className="w-5 h-5 border-2 border-muted-foreground/30 border-t-foreground rounded-full animate-spin" />
                                ) : (
                                  <Search className="w-5 h-5" />
                                )}
                                <span className="font-medium">
                                  {matchLoading ? "Processing..." : "Find Matches"}
                                </span>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                AI-powered face recognition
                              </span>
                            </div>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>
            )}
            
            {/* Settings Tab */}
            {activeTab === "settings" && (
              <div className="space-y-6">
                {!selectedPortfolioId ? (
                  <Card className="border border-border/60">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Settings className="h-5 w-5 text-primary" />
                        Studio Settings
                      </CardTitle>
                      <CardDescription>
                        Configure your studio and client portal settings
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div>
                        <h3 className="text-lg font-medium mb-3">General Settings</h3>
                        <div className="space-y-4">
                          <div className="grid gap-2">
                            <Label htmlFor="studio-name">Studio Name</Label>
                            <Input id="studio-name" placeholder="Leo Photography Studio" defaultValue="Leo Photography Studio" />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="contact-email">Contact Email</Label>
                            <Input id="contact-email" type="email" placeholder="contact@leostudio.com" />
                          </div>
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div>
                        <h3 className="text-lg font-medium mb-3">Security Settings</h3>
                        <div className="space-y-4">
                          <div className="grid gap-2">
                            <Label htmlFor="admin-password">Admin Password</Label>
                            <div className="relative">
                              <Input id="admin-password" type="password" placeholder="••••••••" defaultValue="admin123" />
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="absolute right-0 top-0 h-full"
                                title="Show/Hide Password"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              Password must be at least 8 characters and include letters and numbers
                            </p>
                          </div>
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div>
                        <h3 className="text-lg font-medium mb-3">Portal Settings</h3>
                        <div className="space-y-4">
                          <div className="flex items-start space-x-3">
                            <Checkbox id="watermark" />
                            <div>
                              <Label htmlFor="watermark" className="text-sm font-medium">Enable image watermarks</Label>
                              <p className="text-xs text-muted-foreground">Add your studio watermark to all client preview images</p>
                            </div>
                          </div>
                          
                          <div className="flex items-start space-x-3">
                            <Checkbox id="download-limit" defaultChecked />
                            <div>
                              <Label htmlFor="download-limit" className="text-sm font-medium">Limit downloads</Label>
                              <p className="text-xs text-muted-foreground">Restrict the number of high-res downloads per client</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="flex justify-end gap-3">
                      <Button variant="outline">Cancel</Button>
                      <Button>Save Settings</Button>
                    </CardFooter>
                  </Card>
                ) : (
                  /* Enhanced Settings with QR and Password Management */
                  <div className="space-y-6">
                    {/* QR Code Generation */}
                    <Card className="border border-border/60">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <QrCode className="h-5 w-5 text-primary" />
                          QR Code Generation
                        </CardTitle>
                        <CardDescription>
                          Generate QR codes for easy client access to portfolios
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        {!showQR ? (
                          <Button
                            onClick={() => setShowQR(true)}
                            className="w-full"
                          >
                            <QrCode className="w-4 h-4 mr-2" />
                            Generate QR Code
                          </Button>
                        ) : (
                          <div className="space-y-4">
                            <div className="bg-background p-4 rounded-lg border border-border text-center">
                              <QRCodeCanvas 
                                value={bypassUrl} 
                                size={160}
                                className="mx-auto"
                                ref={qrRef}
                              />
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <Button
                                variant="outline"
                                onClick={handleDownloadQR}
                              >
                                <Download className="w-4 h-4 mr-2" />
                                Download QR
                              </Button>
                              <Button
                                variant="outline"
                                onClick={() => {
                                  navigator.clipboard.writeText(bypassUrl);
                                  toast.success("Link copied to clipboard!");
                                }}
                              >
                                Copy Link
                              </Button>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* Portfolio Password Management */}
                    <Card className="border border-border/60">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Shield className="h-5 w-5 text-primary" />
                          Portfolio Security
                        </CardTitle>
                        <CardDescription>
                          Set password protection for the selected portfolio
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        {!showPasswordInput ? (
                          <Button
                            onClick={() => setShowPasswordInput(true)}
                            className="w-full"
                          >
                            <Shield className="w-4 h-4 mr-2" />
                            Set Portfolio Password
                          </Button>
                        ) : (
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <Label htmlFor="portfolio-password">Portfolio Password</Label>
                              <div className="relative">
                                <Input
                                  id="portfolio-password"
                                  type={isPasswordVisible ? "text" : "password"}
                                  placeholder="Enter secure password..."
                                  value={folderPassword}
                                  onChange={(e) => setFolderPassword(e.target.value)}
                                  className="pr-10"
                                />
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  className="absolute right-0 top-0 h-full w-10"
                                  onClick={() => setIsPasswordVisible(!isPasswordVisible)}
                                >
                                  {isPasswordVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                </Button>
                              </div>
                            </div>
                            <div className="flex gap-3">
                              <Button
                                onClick={handleSetFolderPassword}
                                disabled={!folderPassword}
                                className="flex-1"
                              >
                                Set Password
                              </Button>
                              <Button
                                variant="outline"
                                onClick={() => {
                                  setShowPasswordInput(false);
                                  setFolderPassword("");
                                }}
                              >
                                Cancel
                              </Button>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Image Gallery Section - Shows when portfolio is selected */}
          {selectedPortfolioId && (
            <div className="space-y-6">
              {/* Search Bar */}
              <Card className="border border-border/60">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2">
                    <Search className="h-5 w-5 text-primary" />
                    Search Images
                  </CardTitle>
                  <CardDescription>
                    Search and filter images in the selected portfolio
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder="Search by image name..."
                      className="pl-10"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    {searchTerm && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSearchTerm('')}
                        className="absolute right-2 top-1/2 -translate-y-1/2 h-6 w-6 p-0"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Image Gallery */}
              <Card className="border border-border/60">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Grid3X3 className="h-5 w-5 text-primary" />
                      Gallery ({filteredImages.length} images)
                    </div>
                    <div className="flex items-center gap-3">
                      {/* Select All / Clear All buttons */}
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedImages(new Set(filteredImages.map(img => img.id)))}
                          className="text-xs"
                        >
                          <CheckSquare className="w-3 h-3 mr-1" />
                          Select All
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedImages(new Set())}
                          className="text-xs text-red-400"
                        >
                          <XCircle className="w-3 h-3 mr-1 text-red-400" />
                          Clear All
                        </Button>
                      </div>
                      {selectedImages.size > 0 && (
                        <>
                          <div className="h-4 w-px bg-border"></div>
                          <div className="flex items-center gap-3">
                            <span className="text-sm font-medium">
                              {selectedImages.size} selected
                            </span>
                            <Button
                              onClick={() => handleDownloadSelected()}
                              disabled={downloadLoading}
                              size="sm"
                            >
                              {downloadLoading ? (
                                <>
                                  <div className="w-4 h-4 border-2 border-background/30 border-t-background rounded-full animate-spin mr-2" />
                                  Preparing...
                                </>
                              ) : (
                                <>
                                  <Download className="w-4 h-4 mr-2" />
                                  Download Selected
                                </>
                              )}
                            </Button>
                          </div>
                        </>
                      )}
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {filteredImages.length > 0 ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                      {filteredImages.map((image, index) => (
                        <div
                          key={image.id}
                          className="relative group aspect-square cursor-pointer rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-all"
                          onClick={() => setEnlargedIndex(index)}
                        >
                          <img
                            src={`https://drive.google.com/thumbnail?id=${image.id}&sz=w300`}
                            alt={image.name}
                            className="w-full h-full object-cover transition-transform group-hover:scale-105"
                          />
                          
                          {/* Selection checkbox */}
                          <div 
                            className="absolute top-2 left-2 z-10"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <input
                              type="checkbox"
                              checked={selectedImages.has(image.id)}
                              onChange={(e) => {
                                e.stopPropagation();
                                toggleSelectImage(image.id);
                              }}
                              className="w-4 h-4 rounded border-2 border-white/70 bg-white/10 backdrop-blur checked:bg-primary checked:border-primary cursor-pointer"
                            />
                          </div>

                          {/* Preview indicator */}
                          <div className="absolute bottom-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
                            <div className="w-6 h-6 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center">
                              <Maximize2 className="w-3 h-3 text-white" />
                            </div>
                          </div>

                          {/* Image name overlay - Always visible */}
                          <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/90 via-black/60 to-transparent">
                            <p className="text-white text-xs font-medium truncate">
                              {image.name}
                            </p>
                          </div>

                          {/* Selected indicator */}
                          {selectedImages.has(image.id) && (
                            <div className="absolute inset-0 bg-primary/20 border-2 border-primary rounded-lg" />
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-16 text-center">
                      <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-muted/50 flex items-center justify-center">
                        <Image className="w-8 h-8 text-muted-foreground" />
                      </div>
                      <h3 className="text-lg font-semibold mb-2">No images found</h3>
                      <p className="text-muted-foreground max-w-md mx-auto">
                        {searchTerm 
                          ? `No images match "${searchTerm}". Try adjusting your search.`
                          : "This portfolio is empty or images are still loading."
                        }
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}
          
          {/* Image Lightbox Modal */}
          {enlargedIndex !== null && (
            <div 
              className="fixed inset-0 bg-black/90 backdrop-blur-xl z-[9999] flex items-center justify-center p-4"
              onClick={() => setEnlargedIndex(null)}
            >
              {/* Navigation buttons */}
              {enlargedIndex > 0 && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/10 hover:bg-white/20 text-white border-0 z-[10000]"
                  onClick={(e) => {
                    e.stopPropagation();
                    setEnlargedIndex(enlargedIndex - 1);
                  }}
                >
                  <ChevronLeft className="w-6 h-6" />
                </Button>
              )}
              
              {enlargedIndex < filteredImages.length - 1 && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/10 hover:bg-white/20 text-white border-0 z-[10000]"
                  onClick={(e) => {
                    e.stopPropagation();
                    setEnlargedIndex(enlargedIndex + 1);
                  }}
                >
                  <ChevronRight className="w-6 h-6" />
                </Button>
              )}

              {/* Close button */}
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-4 right-4 w-10 h-10 bg-white/10 hover:bg-white/20 text-white border-0 z-[10000]"
                onClick={() => setEnlargedIndex(null)}
              >
                <X className="w-5 h-5" />
              </Button>

              {/* Main content */}
              <div 
                className="bg-card/80 backdrop-blur rounded-2xl overflow-hidden shadow-2xl max-w-5xl w-full border border-border/50 z-[10000] relative"
                onClick={(e) => e.stopPropagation()}
              >
                <iframe
                  src={`https://drive.google.com/file/d/${filteredImages[enlargedIndex]?.id}/preview`}
                  className="w-full aspect-video"
                  allow="autoplay"
                />
                
                {/* Controls */}
                <div className="p-4 bg-card/80 backdrop-blur border-t border-border/50">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <Button
                        variant={selectedImages.has(filteredImages[enlargedIndex]?.id) ? "default" : "outline"}
                        size="sm"
                        onClick={() => toggleSelectImage(filteredImages[enlargedIndex]?.id)}
                        className="flex items-center gap-2"
                      >
                        {selectedImages.has(filteredImages[enlargedIndex]?.id) ? (
                          <CheckSquare className="w-4 h-4" />
                        ) : (
                          <Square className="w-4 h-4" />
                        )}
                        <span className="font-medium">{filteredImages[enlargedIndex]?.name}</span>
                      </Button>
                    </div>
                    
                    <Button
                      onClick={() => handleDownloadSelected(new Set([filteredImages[enlargedIndex]?.id]))}
                      className="flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      Download
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Hidden File Input */}
          <input
            type="file"
            id="file-input"
            accept="image/*"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="hidden"
          />
          
          {/* Footer */}
          <div className="mt-16 text-center text-muted-foreground text-sm space-y-1">
            <p>© {new Date().getFullYear()} Leo Photography Studio. Admin Panel v1.0</p>
            <p className="text-xs">Built with Next.js and shadcn/ui</p>
          </div>
        </div>
      </div>
    </div>
  );
}

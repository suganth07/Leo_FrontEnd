"use client";

import { useState, useEffect } from "react";
import { createClient } from "@supabase/supabase-js";
import axios from "axios";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Loader2, Download, Search, Upload, XCircle, CheckCircle, Eye, EyeOff, 
  ChevronLeft, Square, CheckSquare, X, Maximize2, ChevronRight, FolderSearch, 
  Camera, User, Shield, Sparkles, Lock, Grid3X3, ImageIcon
} from "lucide-react";
import { Toaster } from "sonner";
import { toast } from "sonner";
import AnimatedBackground from "@/components/ui/AnimatedBackground";
import Navbar from "@/components/ui/navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

// Supabase configuration with fallbacks
const NEXT_PUBLIC_SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';
const NEXT_PUBLIC_SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || '';

// Only create supabase client if we have valid environment variables
const supabase = NEXT_PUBLIC_SUPABASE_URL && NEXT_PUBLIC_SUPABASE_ANON_KEY 
  ? createClient(NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY)
  : null;
const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL; 

console.log("Client Page - BASE_URL:", BASE_URL);

export default function ClientPage() {
  const [folders, setFolders] = useState<{ id: string; name: string }[]>([]);
  const [selectedFolderId, setSelectedFolderId] = useState<string>("");
  const [allImages, setAllImages] = useState<{ id: string; name: string; url: string }[]>([]);
  const [displayImages, setDisplayImages] = useState<{ id: string; name: string; url: string }[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [downloadLoading, setDownloadLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [selectedImages, setSelectedImages] = useState<Set<string>>(new Set());
  const [enlargedIndex, setEnlargedIndex] = useState<number | null>(null);
  const [matchLoading, setMatchLoading] = useState(false);
  const [folderPassword, setFolderPassword] = useState("");
  const [isPasswordVerified, setIsPasswordVerified] = useState(false);
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);

  type Folder = { id: string; name: string };

  useEffect(() => {
    async function fetchFolders() {
      try {
        const res = await axios.get<{ folders: Folder[] }>(
          `${BASE_URL}/api/folders`
        );
        setFolders(res.data.folders ?? []);
        console.log("Fetched folders:", res.data.folders);
      } catch (error) {
        console.error("Error fetching folders:", error);
        toast.error("Unable to load folders");
      }
    }
    if (BASE_URL) fetchFolders();
    else console.warn("BASE_URL is not set");
  }, [BASE_URL]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const folderId = params.get("folderId");
    const bypass = params.get("bypass");

    if (folderId) {
      setSelectedFolderId(folderId);
      if (bypass === "1") {
        setIsPasswordVerified(true);
        fetchImages(folderId);
      }
    }
  }, []);

  useEffect(() => {
    if (selectedFolderId && isPasswordVerified) {
      fetchImages(selectedFolderId);
    }
  }, [selectedFolderId, isPasswordVerified]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (enlargedIndex !== null) {
        if (e.key === "ArrowRight") setEnlargedIndex((prev) => (prev !== null ? (prev + 1) % filteredImages.length : null));
        if (e.key === "ArrowLeft") setEnlargedIndex((prev) => (prev !== null ? (prev - 1 + filteredImages.length) % filteredImages.length : null));
        if (e.key === "Escape") setEnlargedIndex(null);
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [enlargedIndex, displayImages.length]);

  const filteredImages = displayImages.filter(image => 
    image.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  async function fetchImages(folderId: string) {
    try {
      const response = await axios.get(`${BASE_URL}/api/images?folder_id=${folderId}`);
      setAllImages(response.data.images);
      setDisplayImages(response.data.images);
      console.log("Fetched images:", response.data.images.length);
    } catch (error) {
      console.error("Error fetching images:", error);
      toast.error("Failed to load images");
    }
  }

  async function handleMatch() {
    if (!file || !selectedFolderId) {
      toast.error("Please select a folder and upload an image!");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);
    formData.append("folder_id", selectedFolderId);

    try {
      setLoading(true);
      setProgress(0);
      
      const response = await fetch(`${BASE_URL}/api/match`, {
        method: "POST",
        body: formData,
      });

      if (response.status === 404) {
        const errorData = await response.json();
        toast.error(errorData.error || "Encoding file not found. Please contact administrator.");
        return;
      }

      if (!response.ok || !response.body) {
        throw new Error("No response body from server");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let receivedText = "";
      let allMatchedImages: { id: string; name: string; url: string }[] = [];

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        receivedText += decoder.decode(value, { stream: true });
        const events = receivedText.split("\n\n");
        receivedText = events.pop() || "";
        for (const event of events) {
          if (event.startsWith("data: ")) {
            const parsed = JSON.parse(event.replace("data: ", ""));
            if (parsed.progress !== undefined) setProgress(parsed.progress);
            if (parsed.images) allMatchedImages = parsed.images;
          }
        }
      }

      setDisplayImages(allMatchedImages);
      toast.success(`Found ${allMatchedImages.length} matching photos!`);
    } catch (error) {
      console.error("Error matching faces:", error);
      toast.error("Failed to match faces. Try again.");
    } finally {
      setLoading(false);
      setProgress(0);
    }
  }

  async function verifyFolderPassword() {
    if (!selectedFolderId || !folderPassword) {
      toast.error("Please enter a password.");
      return;
    }

    try {
      if (!supabase) {
        toast.error("Database connection not available.");
        return;
      }

      const { data, error } = await supabase
        .from("folders")
        .select("password")
        .eq("folder_id", selectedFolderId)
        .single();

      if (error || !data) {
        toast.error("Folder not found.");
        return;
      }

      console.log("Password verification for folder:", selectedFolderId);

      if (data.password === folderPassword) {
        toast.success("Access granted!");
        setIsPasswordVerified(true);
        fetchImages(selectedFolderId);
      } else {
        toast.error("Incorrect password. Try again.");
      }
    } catch (err) {
      console.error("Error verifying password:", err);
      toast.error("Something went wrong.");
    }
  }

  const toggleSelectImage = (id: string) => {
    const newSelected = new Set(selectedImages);
    if (newSelected.has(id)) newSelected.delete(id);
    else newSelected.add(id);
    setSelectedImages(newSelected);
  };

  const handleDownloadSelected = async (imagesToDownload: Set<string> | null = null) => {
    const imagesToProcess = imagesToDownload || selectedImages;
    
    if (imagesToProcess.size === 0) return;
    
    try {
      setDownloadLoading(true);
      
      for (const fileId of imagesToProcess) {
        const metadataRes = await fetch(`${BASE_URL}/api/file-metadata?file_id=${fileId}`);
        if (!metadataRes.ok) throw new Error(`Failed to fetch metadata for ${fileId}`);
        const { name } = await metadataRes.json();

        const fileRes = await fetch(`${BASE_URL}/api/file-download?file_id=${fileId}`);
        if (!fileRes.ok) throw new Error(`Failed to download file ${fileId}`);
        const blob = await fileRes.blob();

        const url = window.URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", name || `${fileId}.jpg`);
        document.body.appendChild(link);
        link.click();
        link.remove();
      }
      
      toast.success("Download complete!");
    } catch (error) {
      console.error("Error downloading files:", error);
      toast.error("Download failed.");
    } finally {
      setDownloadLoading(false);
    }
  }; 

  const handleSelectAll = () => setSelectedImages(new Set(filteredImages.map(img => img.id)));
  const handleClearAll = () => { 
    setSelectedImages(new Set()); 
    setDisplayImages(allImages); 
    setFile(null); 
  };

  return (
    <div className="min-h-screen bg-background transition-colors duration-300 relative overflow-hidden">
      <AnimatedBackground />
      <Toaster position="top-center" />
      
      {/* Navbar */}
      <Navbar />
      
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Client Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8"
          >
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-primary/10 rounded-lg">
                <Camera className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">Client Portal</h1>
                <p className="text-muted-foreground">Access your personalized photo collection</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="px-3 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium">
                <span>AI-Powered Gallery</span>
              </div>
            </div>
          </motion.div>

          {/* Portfolio Selection */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid lg:grid-cols-3 gap-6"
          >
            {/* Portfolio Selection Card */}
            <Card className="border border-border/60">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <FolderSearch className="h-5 w-5 text-primary" />
                  Select Portfolio
                </CardTitle>
                <CardDescription>Choose your photo collection</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Select
                  value={selectedFolderId}
                  onValueChange={(value) => {
                    setSelectedFolderId(value);
                    setIsPasswordVerified(false);
                    setDisplayImages([]);
                  }}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Choose portfolio..." />
                  </SelectTrigger>
                  <SelectContent>
                    {folders?.map((f) => (
                      <SelectItem key={f.id} value={f.id}>
                        {f.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                {selectedFolderId && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="flex items-center gap-2 text-sm text-foreground p-2 bg-primary/5 rounded-md"
                  >
                    <CheckCircle className="w-4 h-4 text-primary" />
                    <span>Portfolio selected</span>
                  </motion.div>
                )}
              </CardContent>
            </Card>

            {/* Password Verification Card */}
            {selectedFolderId && !isPasswordVerified && (
              <Card className="border border-border/60">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Shield className="h-5 w-5 text-primary" />
                    Access Verification
                  </CardTitle>
                  <CardDescription>Enter your access code</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="relative">
                    <Label htmlFor="password" className="sr-only">Password</Label>
                    <Input
                      id="password"
                      type={isPasswordVisible ? "text" : "password"}
                      placeholder="Enter access code"
                      value={folderPassword}
                      onChange={(e) => setFolderPassword(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && verifyFolderPassword()}
                      className="pr-12"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                      onClick={() => setIsPasswordVisible(prev => !prev)}
                    >
                      {isPasswordVisible ? (
                        <EyeOff className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      )}
                    </Button>
                  </div>
                  
                  <Button
                    onClick={verifyFolderPassword}
                    className="w-full"
                    size="sm"
                  >
                    <Lock className="w-4 h-4 mr-2" />
                    Access Gallery
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Gallery Stats Card */}
            {selectedFolderId && isPasswordVerified && (
              <Card className="border border-border/60">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <ImageIcon className="h-5 w-5 text-primary" />
                    Gallery Stats
                  </CardTitle>
                  <CardDescription>Current collection overview</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Total Photos:</span>
                    <span className="font-semibold">{allImages.length}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Filtered:</span>
                    <span className="font-semibold">{filteredImages.length}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Selected:</span>
                    <span className="font-semibold text-primary">{selectedImages.size}</span>
                  </div>
                </CardContent>
              </Card>
            )}
          </motion.div>

          {/* AI Photo Finder & Controls */}
          {selectedFolderId && isPasswordVerified && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="space-y-6"
            >
              
              {/* AI Photo Matching */}
              <Card className="border border-border/60">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-primary" />
                    AI Photo Finder
                  </CardTitle>
                  <CardDescription>Upload your photo to find all similar images using AI</CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  {/* Upload Preview */}
                  {file && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="p-3 border rounded-lg flex items-center gap-3 bg-muted/20"
                    >
                      <img
                        src={URL.createObjectURL(file)}
                        className="w-12 h-12 object-cover rounded-md"
                        alt="Upload preview"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-sm">{file.name}</p>
                        <p className="text-xs text-muted-foreground">{Math.round(file.size/1024)}KB</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:text-destructive hover:bg-destructive/10 h-8 w-8"
                        onClick={() => setFile(null)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </motion.div>
                  )}
                  
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                    {/* Upload Button */}
                    <div className="relative">
                      <label className="block w-full cursor-pointer group">
                        <div className="p-4 rounded-lg border border-dashed hover:border-primary flex flex-col items-center justify-center gap-2 transition-colors min-h-[80px]">
                          <Upload className="w-5 h-5 group-hover:text-primary transition-colors" />
                          <div className="text-xs font-medium text-center">Upload Photo</div>
                        </div>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => setFile(e.target.files?.[0] || null)}
                          className="hidden"
                        />
                      </label>
                      
                      {file && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          className="absolute -top-1 -right-1 w-6 h-6 rounded-full overflow-hidden border-2 border-primary shadow-lg"
                        >
                          <img 
                            src={URL.createObjectURL(file)} 
                            alt="Preview" 
                            className="w-full h-full object-cover"
                          />
                        </motion.div>
                      )}
                    </div>

                    {/* AI Search Button */}
                    <Button
                      variant="outline"
                      className="h-[80px] flex flex-col items-center justify-center gap-1.5 hover:border-primary/50 transition-colors"
                      onClick={async () => {
                        setMatchLoading(true);
                        await handleMatch();
                        setMatchLoading(false);
                        setFile(null);
                      }}
                      disabled={matchLoading}
                    >
                      {matchLoading ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <Search className="w-5 h-5" />
                      )}
                      <div className="text-xs font-medium text-center">
                        {matchLoading ? "Searching..." : "Find Photos"}
                      </div>
                    </Button>

                    {/* Select All Button */}
                    <Button
                      variant="outline"
                      className="h-[80px] flex flex-col items-center justify-center gap-1.5 hover:border-primary/50 transition-colors"
                      onClick={handleSelectAll}
                    >
                      <CheckCircle className="w-5 h-5" />
                      <div className="text-xs font-medium text-center">Select All</div>
                    </Button>

                    {/* Clear Button */}
                    <Button
                      variant="outline"
                      className="h-[80px] flex flex-col items-center justify-center gap-1.5 hover:border-destructive/50 transition-colors"
                      onClick={handleClearAll}
                    >
                      <XCircle className="w-5 h-5 hover:text-destructive" />
                      <div className="text-xs font-medium text-center">Clear All</div>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Progress Bar */}
              {loading && progress > 0 && (
                <Card className="border border-border/60">
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Processing images...</span>
                        <span>{Math.round(progress)}%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full transition-all duration-300"
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Search Bar */}
              <Card className="border border-border/60">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2">
                    <Search className="h-5 w-5 text-primary" />
                    Search Photos
                  </CardTitle>
                  <CardDescription>Filter photos by name, date, or keywords</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="relative">
                    <Input
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="Search photos..."
                      className="pl-9"
                    />
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
                    {searchTerm && (
                      <Button 
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7"
                        onClick={() => setSearchTerm('')}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Selection Summary */}
              {selectedImages.size > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <Card className="border border-border/60">
                    <CardContent className="p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                          <CheckCircle className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <div className="font-semibold">{selectedImages.size} Photos Selected</div>
                          <div className="text-sm text-muted-foreground">Ready for download</div>
                        </div>
                      </div>
                      <Button
                        onClick={() => handleDownloadSelected()}
                        disabled={downloadLoading}
                        className="flex items-center gap-2"
                      >
                        {downloadLoading ? (
                          <>
                            <Loader2 className="h-4 w-4 animate-spin" />
                            <span>Preparing...</span>
                          </>
                        ) : (
                          <>
                            <Download className="h-4 w-4" />
                            <span>Download Selected</span>
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </motion.div>
          )}

          {/* Image Gallery */}
          {selectedFolderId && isPasswordVerified && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="space-y-6"
            >
              <Card className="border border-border/60">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2">
                    <Grid3X3 className="h-5 w-5 text-primary" />
                    Photo Gallery
                  </CardTitle>
                  <CardDescription>
                    {filteredImages.length > 0 
                      ? `Showing ${filteredImages.length} of ${allImages.length} photos`
                      : "No photos to display"
                    }
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  {filteredImages.length > 0 ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                      {filteredImages.map((image, index) => (
                        <motion.div
                          key={image.id}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.05 }}
                          className="relative group cursor-pointer"
                        >
                          <div 
                            className={`relative rounded-lg overflow-hidden border-2 transition-all duration-200 hover:shadow-lg ${
                              selectedImages.has(image.id) 
                                ? 'border-primary shadow-md' 
                                : 'border-transparent hover:border-border'
                            }`}
                            onClick={() => toggleSelectImage(image.id)}
                          >
                            <div className="aspect-square relative">
                              <img
                                src={`https://drive.google.com/thumbnail?id=${image.id}&sz=w300`}
                                alt={image.name}
                                loading="lazy"
                                decoding="async"
                                className="w-full h-full object-cover"
                                onLoad={(e) => {
                                  const img = e.target as HTMLImageElement;
                                  img.classList.remove('opacity-0');
                                  img.classList.add('opacity-100');
                                }}
                              />
                              
                              {/* Selection overlay */}
                              {selectedImages.has(image.id) && (
                                <div className="absolute inset-0 bg-primary/20 flex items-center justify-center">
                                  <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                                    <CheckSquare className="w-4 h-4 text-white" />
                                  </div>
                                </div>
                              )}
                              
                              {/* Hover overlay */}
                              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-200 flex items-center justify-center">
                                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                                  <Button
                                    size="icon"
                                    variant="secondary"
                                    className="h-8 w-8"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setEnlargedIndex(index);
                                    }}
                                  >
                                    <Maximize2 className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    size="icon"
                                    variant="secondary"
                                    className="h-8 w-8"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleDownloadSelected(new Set([image.id]));
                                    }}
                                  >
                                    <Download className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                            
                            {/* Image info */}
                            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-2">
                              <p className="text-white text-xs truncate">{image.name}</p>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
                        <ImageIcon className="w-8 h-8 text-muted-foreground" />
                      </div>
                      <h3 className="font-semibold mb-2">No Photos Found</h3>
                      <p className="text-muted-foreground text-sm mb-4">
                        {searchTerm 
                          ? `No photos match "${searchTerm}". Try a different search term.`
                          : "Upload a photo using AI Photo Finder to get started."
                        }
                      </p>
                      {searchTerm && (
                        <Button variant="outline" onClick={() => setSearchTerm('')}>
                          Clear Search
                        </Button>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Footer */}
          <div className="mt-16 text-center text-muted-foreground text-sm space-y-1">
            <p>© {new Date().getFullYear()} Leo Photography Studio. Client Portal v1.0</p>
            <p className="text-xs">Powered by AI facial recognition technology</p>
          </div>
        </div>
      </div>

      {/* Enhanced Lightbox Modal */}
      <AnimatePresence>
        {enlargedIndex !== null && (
          <motion.div
            className="fixed inset-0 bg-black/90 backdrop-blur-xl z-50 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setEnlargedIndex(null)}
          >
            {/* Navigation buttons */}
            {enlargedIndex > 0 && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-black/20 hover:bg-black/40 z-20 text-white"
                onClick={(e) => {
                  e.stopPropagation();
                  setEnlargedIndex(enlargedIndex - 1);
                }}
              >
                <ChevronLeft className="h-6 w-6" />
              </Button>
            )}
            
            {enlargedIndex < filteredImages.length - 1 && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-black/20 hover:bg-black/40 z-20 text-white"
                onClick={(e) => {
                  e.stopPropagation();
                  setEnlargedIndex(enlargedIndex + 1);
                }}
              >
                <ChevronRight className="h-6 w-6" />
              </Button>
            )}

            {/* Close button */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/20 hover:bg-black/40 z-20 text-white"
              onClick={() => setEnlargedIndex(null)}
            >
              <X className="h-5 w-5" />
            </Button>

            {/* Main content */}
            <motion.div
              className="bg-card/80 backdrop-blur-md rounded-2xl overflow-hidden shadow-2xl max-w-5xl w-full border border-white/10"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              onClick={(e) => e.stopPropagation()}
            >
              <iframe
                src={`https://drive.google.com/file/d/${filteredImages[enlargedIndex]?.id}/preview`}
                className="w-full aspect-video"
                allow="autoplay"
              />
              
              {/* Controls */}
              <div className="p-4 border-t border-border bg-card/90 backdrop-blur">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <Button
                    variant={selectedImages.has(filteredImages[enlargedIndex]?.id) ? "secondary" : "outline"}
                    className="flex items-center gap-2"
                    onClick={() => toggleSelectImage(filteredImages[enlargedIndex]?.id)}
                  >
                    {selectedImages.has(filteredImages[enlargedIndex]?.id) ? (
                      <CheckSquare className="h-4 w-4" />
                    ) : (
                      <Square className="h-4 w-4" />
                    )}
                    <span className="font-medium">{filteredImages[enlargedIndex]?.name}</span>
                  </Button>
                  
                  <Button
                    className="studio-gradient"
                    onClick={() => handleDownloadSelected(new Set([filteredImages[enlargedIndex]?.id]))}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    <span>Download Photo</span>
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
